import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


os.makedirs("output", exist_ok=True)


df = pd.read_csv('restaurants.csv')



print("\n--- Task 1: Review Length vs Rating ---")


possible_review_cols = ['Reviews', 'Review Text', 'review', 'Dish Liked']
review_col = None
for col in possible_review_cols:
    if col in df.columns:
        review_col = col
        break

if review_col:
    df[review_col] = df[review_col].fillna('').astype(str)
    df['Review Length'] = df[review_col].apply(len)
    avg_review_len = df['Review Length'].mean()
    print(f"Average review length: {avg_review_len:.2f} characters")


    plt.figure(figsize=(8, 6))
    sns.boxplot(x='Aggregate rating', y='Review Length', data=df)
    plt.title('Review Length vs Aggregate Rating')
    plt.tight_layout()
    plt.savefig("output/level3_review_length_vs_rating.png")
    plt.show()
else:
    print("⚠️ No 'Reviews' or similar column found. Skipping Task 1 review analysis.")



print("\n--- Task 2: Votes Analysis ---")

df['Votes'] = pd.to_numeric(df['Votes'], errors='coerce').fillna(0).astype(int)
highest_voted = df.loc[df['Votes'].idxmax()]
lowest_voted = df.loc[df['Votes'].idxmin()]

print(f"Highest Voted Restaurant:\nName: {highest_voted['Restaurant Name']}\nVotes: {highest_voted['Votes']}")
print(f"Lowest Voted Restaurant:\nName: {lowest_voted['Restaurant Name']}\nVotes: {lowest_voted['Votes']}")

plt.figure(figsize=(6, 6))
sns.scatterplot(data=df, x='Votes', y='Aggregate rating')
plt.title('Votes vs Aggregate Rating')
plt.tight_layout()
plt.savefig("output/level3_votes_vs_rating.png")
plt.show()


correlation = df['Votes'].corr(df['Aggregate rating'])
print(f"Correlation between votes and rating: {correlation:.2f}")



print("\n--- Task 3: Price Range vs Services ---")

df['Price range'] = pd.to_numeric(df['Price range'], errors='coerce')
df['Has Online delivery'] = df['Has Online delivery'].fillna('No')
df['Has Table booking'] = df['Has Table booking'].fillna('No')


delivery_by_price = pd.crosstab(df['Price range'], df['Has Online delivery'], normalize='index') * 100
delivery_by_price.plot(kind='bar', stacked=True, figsize=(8, 6), colormap='coolwarm')
plt.title('Online Delivery Availability by Price Range')
plt.ylabel('Percentage')
plt.tight_layout()
plt.savefig("output/level3_delivery_by_price.png")
plt.show()

booking_by_price = pd.crosstab(df['Price range'], df['Has Table booking'], normalize='index') * 100
booking_by_price.plot(kind='bar', stacked=True, figsize=(8, 6), colormap='viridis')
plt.title('Table Booking Availability by Price Range')
plt.ylabel('Percentage')
plt.tight_layout()
plt.savefig("output/level3_booking_by_price.png")
plt.show()
