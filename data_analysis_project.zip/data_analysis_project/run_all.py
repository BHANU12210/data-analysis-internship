import os

print("🔹 Running Level 1 Analysis...")
os.system("python level1_analysis.py")

print("\n🔹 Running Level 2 Analysis...")
os.system("python level2_analysis.py")

print("\n🔹 Running Level 3 Analysis...")
os.system("python level3_analysis.py")

print("\n✅ All analyses completed!")
